function[] = Ass2Environment()
    % clear all
    close all
    clc

    % Creating Robots
    % Linear UR3e Model
    r = LinearUR3e;
    assignin('base', 'r', r);

    % Dobot C5 Model
    %r = Dobot CR5;
    %assignin('base', 'r', r);
    
    % Creating rest of environment
    axis([-3,1,-2,2,-0.5,1]);
    hold on

    % Floor
     surf([-3,-3;1,1], [-2,2;-2,2], [-0.5,-0.5;-0.5,-0.5], 'CData', imread('concrete.jpg'), 'FaceColor', 'texturemap');

    % Tables
    PlaceObject('table.ply',[-0.3,0,-0.55]); 
    PlaceObject('table.ply',[-1.3,0,-0.55]);

    % Safety
    PlaceObject('stopButton.ply',[0,-1.5,-0.5]);
    PlaceObject('fireExtinguisher.ply',[0.5,-1.5,-0.5]);

    % Fencing 
    % Fence 1 - left of UR3
    f1 = PlaceObject('fence.ply',[1.1,-0.22,-0.5]);
    verts = [get(f1,'Vertices'), ones(size(get(f1,'Vertices'),1),1)] * trotz(pi/2);
    verts(:,1) = verts(:,1) *3.7;
    verts(:,2) = verts(:,2);
    set(f1,'Vertices',verts(:,1:3));

    % Fence 2 - right of UR3
    f2 = PlaceObject('fence.ply',[-1.2,-0.22,-0.5]);
    verts = [get(f2,'Vertices'), ones(size(get(f2,'Vertices'),1),1)] * trotz(pi/2);
    verts(:,1) = verts(:,1) *3.7;
    verts(:,2) = verts(:,2);
    set(f2,'Vertices',verts(:,1:3));

    % Fence 3 - behind UR3
    f3 = PlaceObject('fence.ply',[0.7,0,-0.5]);
    verts = [get(f3,'Vertices'), ones(size(get(f3,'Vertices'),1),1)];   
    verts(:,1) = verts(:,1);
    verts(:,2) = verts(:,2) *3;
    set(f3,'Vertices',verts(:,1:3));

    % Fence 4 - front of UR3
    f4 = PlaceObject('fence.ply',[-2.3,0,-0.5]);
    verts = [get(f4,'Vertices'), ones(size(get(f4,'Vertices'),1),1)];
    verts(:,1) = verts(:,1);
    verts(:,2) = verts(:,2) *3;
    set(f4,'Vertices',verts(:,1:3));

end